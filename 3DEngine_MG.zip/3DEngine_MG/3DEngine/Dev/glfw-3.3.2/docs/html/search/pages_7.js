var searchData=
[
  ['release_20notes_788',['Release notes',['../news.html',1,'']]]
];
