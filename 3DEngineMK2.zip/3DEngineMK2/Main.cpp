#pragma once
#include "Engine/Graphics/Shaders/Shader.h"
#include"Engine/Engine.h"
#include "Engine/Graphics/Sprite.h"
#include "Engine/Input/Input.h"
#include "Engine/Graphics/3DObject.h"


int main() 
{
	Engine Engine;
	Engine.init((char*)"Name");
	glm::vec3 c(1, 1, 100);
	Sprite Test = Sprite("Assets/Texture/test_30.png",100,100);
	Test.setPos(10, 10);
	Test.setScale(1);
	Object3d o(c, 100,("Assets/Texture/test_30.png"));
	
	//Shader Currently broken
	//Shader ourShaer("Assets/Shader/ShaderTest.vs", "Assets/Shader/FragTest.fs", 0);
	//
	while(true)
	{
		Engine.update();
		Test.update();
		
		
		//Test.setPos((float)Mouse::getCursorX(), (float)Mouse::getCursorY());
		//Test.MovePos();
		o.MovePos((float)Mouse::getCursorX(),(float)Mouse::getCursorY()),0;
		if(Mouse::Button(GLFW_MOUSE_BUTTON_LEFT))
		{
			Test.incRot(1);

		}
		if(Mouse::ButtonPress(GLFW_MOUSE_BUTTON_RIGHT))
		{
			Test.setRotTo(180);
			//o.MovePos(50, 0, 0);
		
		}
		if (Keyboard::Key(GLFW_KEY_W)) 
		{
			Test.incRot(10);
		}
		if (Keyboard::KeyPress(GLFW_KEY_A))
		{

			Test.incRot(-10);
		
		
		}
		if(Keyboard::KeyUp(GLFW_KEY_D))
		{
			Test.setRotTo(90);
		
		
		}
	
		Engine.ClearSc();
		//ourShaer.use();
		o.drawCube();
		Test.render();

		Engine.NextFrame();
	
	}


}