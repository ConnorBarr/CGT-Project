#pragma once

#include <GLFW/glfw3.h>
#pragma comment(lib, "opengl32.lib")

class Engine 
{
private:
	static GLFWwindow* window;
	static float deltaTime;
	float lastFT;
public:
	//note change later to allow change in res
	static int SCR_Width;
	static int SCR_Height;
	static float getdeltaTime();
	//
	Engine();
	~Engine();

	void update();
	void render();

	void ClearSc();
	void NextFrame();

	bool init(char* winName);
};