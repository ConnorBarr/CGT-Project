#pragma once

#include "Texture.h"

Texture::Texture()
{
	id = -1;
}

Texture::Texture(int ID)
{
	id = ID;
	
		if (!textureParam())
		{
			std::cout<< "ID not found" << std::endl;
		}

	

}

Texture::Texture(std::string local)
{

	id = SOIL_load_OGL_texture(local.c_str(), SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MULTIPLY_ALPHA | SOIL_FLAG_INVERT_Y);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, &id);
	if(!textureParam())
	{
		std::cout << local << "not found" << std::endl;
	}
	
}

bool Texture::textureParam() 
{
	
	if(id>0)
	{
		int mipL = 0;
		glBindTexture(GL_TEXTURE_2D, id);
		glGetTexLevelParameteriv(GL_TEXTURE_2D, mipL, GL_TEXTURE_WIDTH, &width);
		glGetTexLevelParameteriv(GL_TEXTURE_2D, mipL, GL_TEXTURE_HEIGHT, &height);
		return true;

	}
	else
	{
		return false;
	}

	
}

int Texture::getID()
{
	return id;
}
int Texture::getHeight()
{
	return height;
}
int Texture::getWidth()
{
	return width;
}