#pragma once

#include <GLFW/glfw3.h>
#include "Texture.h"
#include <vector>
#include <glm/glm.hpp>
#include <glm/common.hpp>
#include <vector>

class Object3d
{

private:
	Texture texTure;
	float rotation;
	float xScale;
	float yScale;
	float zScale;
	float xPos;
	float yPos;
	float zPos;
	float Speed;
	GLfloat halfsizelength;
	float x, y, z;
	float vertices[72];
	float texCord[48];
	unsigned int buffer;
	unsigned int VB0;

	
	


public:
	void drawCube();
	Object3d(glm::vec3 c ,GLfloat edgeLength,std::string pathTexture);
	void Resize(float size);
	void MovePos(float x);
	void MovePos(float x, float y);
	void MovePos(float x, float y, float z);
	





};