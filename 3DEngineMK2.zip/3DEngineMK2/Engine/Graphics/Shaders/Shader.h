#pragma once

#include <gl/glew.h>
#include <glm/glm.hpp>


#include <string>
#include <fstream>
#include <sstream>
#include <iostream>

class Shader
{

private:
	std::string vertexCode;
	std::string fragCode;
	std::ifstream verShaderFile;
	std::ifstream fragShaderFile;


	unsigned int id;
public:	
	Shader(const char* vertPath, const char* fragPath,int g);
	void checkCompileErrors(GLuint shader, std::string type);
	void use();

};
