#pragma once
#include "3DObject.h"
#include <iostream>





Object3d::Object3d(glm::vec3 c, GLfloat edgeLength,std::string texture)
{
	Speed = 0;
	rotation = 0;
	xScale = 1;
	yScale = 1;
	halfsizelength = edgeLength * 0.5;

	texTure = Texture(texture);

	float x, y, z;

	x = c.x;
	y = c.y;
	z = c.z;

	float vert[72]
	{
		x - halfsizelength, y + halfsizelength,z + halfsizelength,
		x + halfsizelength, y + halfsizelength,z + halfsizelength,
		x + halfsizelength, y - halfsizelength,z + halfsizelength,
		x - halfsizelength, y - halfsizelength,z + halfsizelength,

		x - halfsizelength, y + halfsizelength,z - halfsizelength,
		x + halfsizelength, y + halfsizelength,z - halfsizelength,
		x + halfsizelength, y - halfsizelength,z - halfsizelength,
		x - halfsizelength, y - halfsizelength,z - halfsizelength,

		x - halfsizelength, y + halfsizelength,z + halfsizelength,
		x - halfsizelength, y + halfsizelength,z - halfsizelength,
		x - halfsizelength, y - halfsizelength,z - halfsizelength,
		x - halfsizelength, y - halfsizelength,z + halfsizelength,

		x + halfsizelength, y + halfsizelength,z + halfsizelength,
		x + halfsizelength, y + halfsizelength,z - halfsizelength,
		x + halfsizelength, y - halfsizelength,z - halfsizelength,
		x + halfsizelength, y - halfsizelength,z + halfsizelength,

		x - halfsizelength, y + halfsizelength,z + halfsizelength,
		x - halfsizelength, y + halfsizelength,z - halfsizelength,
		x + halfsizelength, y + halfsizelength,z - halfsizelength,
		x + halfsizelength, y + halfsizelength,z + halfsizelength,

		x - halfsizelength, y - halfsizelength,z + halfsizelength,
		x - halfsizelength, y - halfsizelength,z - halfsizelength,
		x + halfsizelength, y - halfsizelength,z - halfsizelength,
		x + halfsizelength, y - halfsizelength,z + halfsizelength,








	};

	float Tex[48]
	{
		0,0,
		0,1,
		1,0,
		1,1,

		0,0,
		0,1,
		1,0,
		1,1,

		0,0,
		0,1,
		1,0,
		1,1,

		0,0,
		0,1,
		1,0,
		1,0,

		0,0,
		0,1,
		1,0,
		1,1,

		0,0,
		0,1,
		1,0,
		1,1,
	
	
	
	
	
	
	
	
	
	
	
	};


	for (int x = 0; x <= 71; x++)
	{

		vertices[x] = vert[x];

	}
	
	
		for (int x = 0; x < 47; x++)
		{
			texCord[x] = Tex[x];
		}
	
		

	
};

void Object3d::drawCube()
{

	//glLoadIdentity();
	glPopMatrix();

	//Translate
	glTranslatef(xPos, yPos, 0);
	//Roate
	glRotatef(0, 0, 0, 0);
	//Scale
	glScalef(1, 1, 1);
	
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	glBindTexture(GL_TEXTURE_2D, texTure.getID());
	

	glEnableClientState(GL_VERTEX_ARRAY);
	glEnableClientState(GL_TEXTURE_COORD_ARRAY);


	
	
	glVertexPointer(3, GL_FLOAT, 0, vertices);
	glTexCoordPointer(2, GL_FLOAT, 0, texCord);
	glDrawArrays(GL_QUADS, 0, 24);
	glDisableClientState(GL_VERTEX_ARRAY);
	glDisableClientState(GL_TEXTURE_COORD_ARRAY);

	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glPushMatrix();
	glPopMatrix();
}

void Object3d::Resize(float size)
{
	for(int x=0;x <=71;x++)
	{
		vertices[x] * size;
	
	
	}
	

}
void Object3d::MovePos(float x, float y, float z)
{
	xPos = x;
	yPos = y;
	z = z;
}
void Object3d::MovePos(float x, float y)
{
	xPos = x;
	yPos = y;
	
}
void Object3d::MovePos(float x)
{
	glTranslatef(x,0,0);
}
