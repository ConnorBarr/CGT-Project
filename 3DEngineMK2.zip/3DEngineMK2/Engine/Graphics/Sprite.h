#pragma once


#include <GLFW/glfw3.h>
#include "Texture.h"
#include<iostream>
#include <string>

class Sprite
{
private:
	Texture texture;
	float yPos;
	float xPos;
	float rotation;
	float xScale;
	float yScale;
	float Speed;
public:
	Sprite();
	Sprite(Texture texture);
	Sprite(std::string ipath);
	Sprite(std::string ipath, float RxPos , float RyPos);

	void setPos(float x, float y);
	void setRotation(float i);
	void setScale(float x);
	void setScale(float x,float y);
	void setRotTo(float i);
	void incRot(float i);
	void MovePos();
	void MovePos(float x);
	void MovePos(float x,float y);
	void setSpeed(float s);

	void update();
	void render();






};